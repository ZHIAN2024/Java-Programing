package week4;

public class Labtask1 {

        public static void main(String[] args) {
            double miles = 100;
            final double kilometers_per_miles = 1.609;
            double kilometers = miles * kilometers_per_miles;
            System.out.println(kilometers);
        }
    }


